@include('header')
<style>
    form{
        display: inline;
    }
    .table1 {

margin-left: 50px;
margin-right: 50px;

}

.tt {
background: transparent !important;
color: #fff !important;


}
.bb{
text-decoration: none;
color: #fff;
border: 1px solid #2a9191;
border-radius:12px;
padding: 12px 34px;
font-size: 18px;
background: #2a9191;
position: relative;
cursor: pointer;
}

.bb:hover {
border: 1px solid #fff;
background: transparent;
color: #fff;
transition: 0.8s;
}
</style>
<main>
    <div class="container">
        <div class="row">
            <div class=" text-center border rounded my-5">
                <h3 style="color: #fff;">My Cart</h3>
            </div>
            <div class="col-lg-9">
                <div class="table1">
                    <table class="table text-center table-hover table-bordered ">
                        <thead>
                @if (session('cart') && count(session('cart')) > 0)
                    <tr>
                        <th class="tt">img</th>
                        <th class="tt">name</th>
                        <th class="tt">quantity</th>
                        <th class="tt">Price</th>
                        <th class="tt">category</th>
                        <th class="tt">Total</th>
                        <th class="tt">Action</th>
                    </tr>
            </thead>
            <tbody class="text-center">

                @php
                    $total = 0;
                @endphp
                @foreach (session('cart') as $k => $v)
                    @php
                        $total += $v['price'] * $v['qty'];
                    @endphp
                    <tr>
                        <td class="tt"><img style="width:50px; height:50px;" src="{{ asset('upload') }}/{{ $v['pimage'] }}"
                                alt=""></td>
                        <td class="tt">{{ $v['pname'] }}</td>
                        <td class="tt">
                            <form method="post" action="{{ URL::to('/quanminus') }}">
                                @csrf
                                <button type="submit" name="sub" class="btn btn-small btn-success">-</button>
                                <input type="hidden" name="hidid" value="{{ $v['pid'] }}">
                            </form>
                            <input name="qtty" style="background:none; border:none;" class="text-center text-light"
                                type="number" min="1" max="5" value="{{ $v['qty'] }}" disabled>
                            <form method="post" action="{{ URL::to('/quanplus') }}">
                                @csrf
                                <input type="hidden" name="hidid" value="{{ $v['pid'] }}">
                                <button type="submit" name="add" class="btn btn-small btn-success">+</button>
                            </form>
                        </td>
                        <td class="tt">{{ $v['price'] }} ₹</td>
                        <td class="tt">{{ $v['category'] }}s</td>
                        <td class="tt">{{ $v['price'] * $v['qty'] }} ₹</td>
                        <td class="tt">
                            <form method="post" action="{{ URL::to('/deletecart') }}">
                                @csrf
                                <button type="submit" name="del" class="btn  btn-outline-danger">Remove</button>
                                <input type="hidden" name="hidid" value="{{ $v['pid'] }}">
                            </form>
                        </td>
                    </tr>
                @endforeach
                <tr>
                    <!-- @if (session('cat'))
                        <td class="tt" colspan="3">
                            <form action="{{ URL::to('/goback') }}" method="post">
                                @csrf
                                
                                <button style="width:45%;" class="btn btn-large btn-success text-light "
                                    type="submit"><span></span>back</button>
                            </form>
                        </td>
                    @else
                        <td class="tt" colspan="3"></td>
                    @endif -->
                    <td class="tt" colspan="3"></td>
                    <td class="tt" colspan="2">Grand Total:</td>
                    <td class="tt"> {{ $total }} ₹</td>
                    <td class="tt"><a class=" btn btn-outline-warning" href="{{ URL::to('/logout') }}">checkout</a></td>
                </tr>
            @else
                <tr>
                    <td class="tt" colspan="7" class="text-center">
                        <h3>No Products Are There.</h3>
                    </td>
                </tr>
                @endif
            </tbody>
        </table>

    </div>
</main>
