<?php

namespace App\Http\Controllers;

//use GuzzleHttp\Psr7\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
//user
    function product(){
        $dat=DB::table('category')->orderBy('cid','desc')->paginate(2);
        return view('product',['dat'=>$dat]);
        
    }
    function about(){
        return view('about');
    }

    function product2($cat){
        session()->put('cat',request()->fullUrl());
        $dat=DB::table('products')->where('category',$cat)->orderBy('pid','desc')->paginate(2);
        $i=1;
        return view('product2',['dat'=>$dat]);
        // print_r($dat);
    
    }

    function advice(){
        $dat=DB::table('beauty_advice')->paginate();
       
        return view('advice',['dat'=>$dat]);

    }

//*************************************************************************** */
    //admin
    function dashboard(){
        $cat=DB::table('category')->get();
        $prod=DB::table('products')->get();
        $user=DB::table('users')->get();
        $adv=DB::table('beauty_advice')->get();

       return view('dashboard',['cat'=>$cat,'prod'=>$prod,'user'=>$user,'adv'=>$adv]);
    }

   
    function adminuser(){
        $dat2=DB::table('users')->get();
        $dat=json_decode(json_encode($dat2),true);
        $a=1;
        return view('adminuser',['dat'=>$dat,'a'=>$a]);

    }
    function delteuser(Request $req){
        $uid1=$req->uid;
        $dat2=DB::table('users')->where('user_id',$uid1)->delete();
       
        if(!$dat2){
            echo "<script> alert('User Not Removed')</script>";
        }else{
        echo "<script> alert('User Removed Succesfully')</script>";
        }
        return redirect('user');
    }

    function adminproduct(){
        $dat2=DB::table('products')->get();
        $dat=json_decode(json_encode($dat2),true);
        $a=1;
        return view('adminproduct',['dat'=>$dat,'a'=>$a]);

    }
    // function addadmin(Request $req){
    //     $pname=$req->pn;

    // }
    function adminupd(Request $req){
        if($req->action==='remove'){
            $pid=$req->pid;
            $dat2=DB::table('products')->where('pid',$pid)->delete();
       
            if(!$dat2){
                echo "<script> alert('Product Not Removed')</script>";
                return redirect('adminproduct');
            }else{
            echo "<script> alert('Product Removed Succesfully')</script>";
            return redirect('adminproduct');
            }
        }else if($req->action==='update'){
            $n = $req->nm;
            $c = $req->cat;
            $p = $req->pric;
            $q = $req->qty;
            $d = $req->des;
            $pid = $req->pid;

        }
        
    }

    function admincat(){
        $cat2=DB::table('category')->get();
        $cat=json_decode(json_encode($cat2),true);
        $a=1;
        return view('admincat',['cat'=>$cat,'a'=>$a]);
    }
    function addcat(Request $req){
        $catnm=$req->catnm;
        $file=$req->file;
        $filenm=time().'_'.$file->getClientOriginalName();
        
    }
    function catdel(Request $req){
        $cid=$req->cid;
        $query=DB::table(('category'))->where('cid',$cid)->delete();
        if(!$query){
            echo "<script> alert('Category Not Removed')</script>";
            return redirect('admincat');
        }else{
            echo "<script> alert('Category Removed Succesfully')</script>";
            return redirect('admincat');
        }    

    }

    function adminadvice(){
        $dat2=DB::table('beauty_advice')->get();
        $dat=json_decode(json_encode($dat2),true);
        $a=1;
        return view('adminadvice',['dat'=>$dat,'a'=>$a]);
    }
    function adviceupd(Request $req){
        if($req->action==='remove'){
        $bid=$req->bid;
            
        $query=DB::table(('beauty_advice'))->where('ba_id',$bid)->delete();
            if(!$query){
                echo "<script> alert('Beauty Advice Not Removed')</script>";
                return redirect('adminadvice');
            }else{
                echo "<script> alert('Beauty Advice Removed Succesfully')</script>";
                return redirect('adminadvice');
            }            }
    }



    function managecart(Request $req){
        $prodata=[
        'id'=>$req->hidid,
        'name'=>$req->hidnm,
        'price'=>$req->hidpr,
        'img'=>$req->hidimg,
        'cat'=>$req->hidcat,
        'qty'=>$req->hidqty,
        ];

        if(session()->has("cart")){
            $cartdata=session()->get("cart");
            
            $pidd=array_column($cartdata,'id');
            if(in_array($req->hidid,$pidd)){
                echo "<script> alert('Product Added')</script>";
                return view('product');

            }else{
                $newCartItem = [
                    'id' => request('hidid'),
                    'name' => request('hidnm'),
                    'price' => request('hidpr'),
                    'img' => request('hidimg'),
                    'qty' => request('hidqty'),
                    'cat' => request('hidcat'),
                ];
                $checkcart=session("cart",[]);
                $checkcart[]=$newCartItem;
                session(['cart' => $checkcart]);

            }
            
        }else{
            session()->push("cart",$prodata);
            echo "<script> alert('Product Added')</script>";
          
        }
    }

    function cart(Request $req){
        

        $cart=session()->get('cart',[]);
        
            $productids = array_column($cart, 'pid');
            //  print_r($productids);
            
        if (count($cart)>0)
        {
            if(in_array($req->hiddid, $productids)){
                echo '<script> alert("Product Already Added");window.location.href="'.session('cat').'";</script>';
                
            }else{
                $count=count($cart);
                $cart[$count]=[
                    'pid' => $req->hiddid,
                    'pname' => $req->hiddname,
                    'pimage' => $req->hiddimage,
                    'qty' => $req->hiddqty,
                    'category' => $req->hiddcate,
                    'price' => $req->hiddprice
                ];
                
                session()->put('cart',$cart);
                
                echo '<script> alert("Product Added");window.location.href="'.session('cat').'";</script>';
                
            }
            
        }
        else{
            
            $cart[0]=[
                'pid' => $req->hiddid,
                'pname' => $req->hiddname,
                'pimage' => $req->hiddimage,
                'qty' => $req->hiddqty,
                'category' => $req->hiddcate,
                'price' => $req->hiddprice
            ];
            session()->put('cart',$cart);
            echo '<script> alert("Product Added");window.location.href="'.session('cat').'";</script>';


        }
        // echo'<pre>';
        //         print_r(session()->all());
        //         echo'<pre>';
    }

    function quanminus(Request $req){
        $del=session()->get('cart',[]);
        $hid=$req->hidid;
        foreach($del as $k=>$v){
            if($hid==$v['pid']){
                if($del[$k]['qty']>1){
                    $del[$k]['qty']--;
                    session()->put('cart',$del);
                    echo '<script>window.location.href="cart";</script>';
    
                }else{
                    echo '<script> alert("You have Selected Minimum Qty"); window.location.href="cart";</script>';
                }
    
            }
        }

        

    }
    function quanplus(Request $req){
        $del=session()->get('cart',[]);
        $hid=$req->hidid;
        foreach($del as $k=>$v){
            if($hid==$v['pid']){
                if($del[$k]['qty']<5){
                    $del[$k]['qty']++;
                    session()->put('cart',$del);

                    echo '<script>window.location.href="cart";</script>';
    
                }else{
                    echo '<script> alert("You have Selected Maximum Qty"); window.location.href="cart";</script>';
                }
    
            }
        }

    }
    function deletecart(Request $req){
        $del=session()->get('cart',[]);

        $hid=$req->hidid;
    foreach($del as $k=>$v){
        if($hid==$v['pid']){
            unset($del[$k]);
            $del=array_values($del);
            session()->put('cart',$del);
            echo '<script> alert("Product removed"); window.location.href="cart";</script>';
        }
    }
    }

    function signin(Request $req){

        $usernm=$req->txtusernm;
        $pswd=$req->pass;
        $pa=md5($pswd);
        if(!session('usersession')){
            $userch=DB::table('users')->where('username',$usernm)->get();
            if(count($userch)>0){
                $query=DB::table('users')->where('username',$usernm)->where('password',$pa)->get();
                $jsd=json_decode(json_encode($query));
               
                if(count($query)>0){
                    
                    return view('home',['usenm'=>$usernm]);
                }
                else{
                    echo '<script> alert("Password Incorrect Try again");window.location.href="signin";</script>';
                }
            }else{
                echo '<script> alert("User Name Incorrect Try again");window.location.href="signin";</script>';
        }
    }else{
        echo '<script> alert("You are already login");window.location.href="home";</script>'; 


    }
    }

    function logout(){
        session()->forget('usersession');
        echo '<script> alert("User Name Incorrect Try again");window.location.href="signin";</script>';
    }


}
